import tkinter as tk
from tkinter import filedialog as fd



if __name__ == '__main__':
    fd.askopenfilename(initialdir=r"C:\Users",
                                   filetypes=(('Portable Network Graphics', '*.png'),
                                              ("All files", "*.*")))
    #root.mainloop()
