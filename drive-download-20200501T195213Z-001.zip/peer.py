import socket
import os
import threading
import time
value = []
HOST = '10.70.235.100'
port = 5000


def main(s):
    req = input("upload or download (u/d) or exit ")
    if req == "exit":
        s.send(req.encode())
        exit()
    elif req == "u":
        try:
            s.send(req.encode())
            upload(s)
        except:
            print("connection aborted")
            exit()
    elif req == "d":
        try:
            s.send(req.encode())
            download(s)
        except:
            print("connection aborted")
            exit()
    else:
        print("wrong input")
        main(s)
    main(s)


# TODO
def main_new(s, req, var):
    print('MAIN NEW ENTERED')
    if req == "exit":
        s.send(req.encode())
        exit()
    elif req == "u":
        try:
            s.send(req.encode())
            upload_new(s, var)
        except:
            print("connection aborted")
            exit()
    elif req == "d":
        try:
            new_download(s, var)
        except:
            print("connection aborted")
            exit()


# TODO
def upload(s):
    file = input("enter file path ")
    if not os.path.isfile(file):
        print("not a file")
        upload(s)
    name = file.split("\\")[-1]
    print(name)
    with open(file, 'rb') as the_file:
        sz = len(the_file.read())
    try:
        s.send((name + ":" + str(sz)).encode())
    except:
        print("connection aborted")
        exit()
    threading.Thread(target=newFile, args=(s, file)).start()


def upload_new(s, file):
    print('UPLOAD NEW ENTERED')
    name = file.split("\\")[-1]
    print(name)
    with open(file, 'rb') as the_file:
        sz = len(the_file.read())
    try:
        s.send((name + ":" + str(sz)).encode())
    except IOError:
        print("connection aborted")
        exit()
    print(file)
    threading.Thread(target=newFile_new, args=(s, file)).start()


def newFile(s, file):
    while True:
        data = ''
        try:
            data = s.recv(1024).decode()
        except IOError:
            print("connection aborted")
            exit()
        print(data)
        data = data.split()
        try:
            newServer(data[1], data[2], data[3], file)
        except IOError:
            exit()


def newFile_new(s, file):
    print('NEWFILE NEW ENTERED')
    while True:
        data = ''
        try:
            data = s.recv(1024).decode()
        except IOError:
            print("connection aborted")
            exit()
        print(data + "sdf")
        data = data.split()
        try:
            newServer(data[1], data[2], data[3], file)
        except IOError:
            exit()


def download(s):
    global value
    data = ''
    try:
        data = s.recv(2048).decode()
        print(data)
        data = data.split(':')
        dest = input("insert file name ")
        dest = check(data, dest)
        s.send(dest.encode())
        data = s.recv(1024).decode().split()
    except IOError:
        print("connection aborted")
        exit()
    value = []
    i = 1
    for x in data[1:]:
        threading.Thread(target=newClient, args=(x, i)).start()
        i += 1
    while True:
        if len(value) == int(data[0]):
            break
    string = b""
    index = 1
    while index <= int(data[0]):
        for i in value:
            if i[1] == index:
                string += i[0]
                value.remove(i)
                break
        index += 1
    file = open(dest, 'wb')
    file.write(string)
    print("done " + dest)
    threading.Thread(target=newFile, args=(s, dest)).start()


def new_download(s, file_sad):
    global value
    data = ''
    dest = ''
    try:
        dest = file_sad
        s.send(dest.encode())
        data = s.recv(1024).decode()
        print(data)
        data = data.split()
    except IOError:
        print("connection aborted")
        exit()
    value = []
    i = 1
    for x in data[1:]:
        print(x)
        threading.Thread(target=newClient, args=(x, i)).start()
        i += 1
    while True:
        if len(value) == int(data[0]):
            break
    string = b""
    index = 1
    while index <= int(data[0]):
        for i in value:
            if i[1] == index:
                string += i[0]
                value.remove(i)
                break
        index += 1
    newpath = "files"
    if not os.path.exists(newpath):
        os.makedirs(newpath)
    file = open(newpath + "\\" + dest, 'wb')
    file.write(string)
    print("done " + dest)
    threading.Thread(target=newFile_new, args=(s, "files\\"+dest)).start()


def down_file(s):
    global value
    data = s.recv(1024).decode()
    if data == "waiting for more peers":
        data = s.recv(2048).decode()
    print(data)
    data = data.split(':')
    dest = input("insert file name ")
    dest = check(data, dest)
    s.send(dest.encode())
    data = s.recv(1024).decode().split()
    value = []
    i = 1
    for x in data[1:]:
        threading.Thread(target=newClient, args=(x, i)).start()
        i += 1
    while True:
        if len(value) == int(data[0]):
            break
    string = b""
    index = 1
    while index <= int(data[0]):
        for i in value:
            if i[1] == index:
                string += i[0]
                value.remove(i)
                break
        index += 1
    file = open(dest, 'wb')
    file.write(string)
    print("done " + dest)
    threading.Thread(target=newFile, args=(s, dest)).start()


def newClient(dest, id):
    global value
    port = 5050
    print("started")
    c = socket.socket()
    c.connect((dest, port))
    try:
        received = c.recv(1024)
    except IOError:
        print("connection aborted")
        exit()
    while received[-4:] != b'done':
        received += c.recv(1024)
    received = received[:-4]
    value.append([received, id])
    c.close()


def reconect_new(mode, var):
    print('MAIN NEW ENTERED')
    main(s)


def newServer(dest, start, stop, file):
    print("newServer " + dest)
    with open(file, 'rb') as the_file:
        my_string = the_file.read()[int(start):int(stop)]
    ser = socket.socket()
    ser.bind(("0.0.0.0", 5050))
    print("started accept")
    ser.listen(5)
    print("accept 1")
    c, addr = ser.accept()
    while addr[0] != dest:
        c, addr = ser.accept()
    print("accept 2")
    try:
        c.send(my_string)
        c.send(b"done")
        c.close()
    except:
        c.close()
    print("done with upload")


def check(files, name):
    for x in files:
        if name == x:
            return name
    print("not in list")
    return check(files, input("insert file name "))


if __name__ == '__main__':
    s = socket.socket()
    try:
        s.connect((HOST, port))
    except:
        print("connection aborted")
        exit()
    main(s)
